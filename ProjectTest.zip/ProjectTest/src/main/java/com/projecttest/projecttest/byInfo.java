package com.projecttest.projecttest;

public abstract class byInfo extends Info{

}
