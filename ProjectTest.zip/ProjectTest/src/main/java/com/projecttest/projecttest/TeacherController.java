package com.projecttest.projecttest;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TeacherController {

    @FXML
    private VBox contentArea;
    @FXML
    private Button coursesButton;
    @FXML
    private Button addTaskButton;
    @FXML
    private Button studentsButton;
    @FXML
    private Button backButtonPrev;
    @FXML
    private Button backButtonLogin;
    @FXML
    private Label statusLabel;

    @FXML
    private void initialize() {
        statusLabel.setText("Welcome to Teacher Dashboard");
    }

    @FXML
    private void handleManageCourses() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Courses Managed:"));
        try {
            Connection conn = Database.getConnection();
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT title, description FROM courses WHERE instructor_id = (SELECT id FROM users WHERE role = 'Teacher' LIMIT 1)"
            );
            while (rs.next()) {
                contentArea.getChildren().add(new Label(rs.getString("title") + " - " + rs.getString("description")));
            }
            conn.close();
            statusLabel.setText("Courses loaded");
        } catch (SQLException e) {
            statusLabel.setText("Error loading courses: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddTask() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Add New Assignment:"));

        TextField titleField = new TextField();
        titleField.setPromptText("Assignment Title");
        TextField descriptionField = new TextField();
        descriptionField.setPromptText("Description");
        TextField dueDateField = new TextField();
        dueDateField.setPromptText("Due Date (YYYY-MM-DD HH:MM:SS)");
        TextField maxGradeField = new TextField();
        maxGradeField.setPromptText("Max Grade");
        TextField courseIdField = new TextField();
        courseIdField.setPromptText("Course ID");

        Button submitButton = new Button("Submit Assignment");
        submitButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 20; -fx-background-radius: 5;");

        submitButton.setOnAction(e -> {
            String title = titleField.getText().trim();
            String description = descriptionField.getText().trim();
            String dueDate = dueDateField.getText().trim();
            String maxGradeStr = maxGradeField.getText().trim();
            String courseIdStr = courseIdField.getText().trim();

            if (title.isEmpty() || description.isEmpty() || dueDate.isEmpty() || maxGradeStr.isEmpty() || courseIdStr.isEmpty()) {
                statusLabel.setText("Please fill all fields");
                return;
            }

            int maxGrade, courseId;
            try {
                maxGrade = Integer.parseInt(maxGradeStr);
                courseId = Integer.parseInt(courseIdStr);
                if (maxGrade <= 0) {
                    statusLabel.setText("Max Grade must be positive");
                    return;
                }
            } catch (NumberFormatException ex) {
                statusLabel.setText("Max Grade and Course ID must be valid numbers");
                return;
            }

            try {
                Connection conn = Database.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(
                        "INSERT INTO assignments (course_id, title, description, due_date, max_grade, created_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)"
                );
                pstmt.setInt(1, courseId);
                pstmt.setString(2, title);
                pstmt.setString(3, description);
                pstmt.setString(4, dueDate);
                pstmt.setInt(5, maxGrade);
                int rowsAffected = pstmt.executeUpdate();
                conn.close();

                if (rowsAffected > 0) {
                    statusLabel.setText("Assignment added successfully");
                    contentArea.getChildren().clear();
                    contentArea.getChildren().add(new Label("Assignment Added: " + title));
                } else {
                    statusLabel.setText("Failed to add assignment");
                }
            } catch (SQLException ex) {
                statusLabel.setText("Database error: " + ex.getMessage());
            }
        });

        contentArea.getChildren().addAll(titleField, descriptionField, dueDateField, maxGradeField, courseIdField, submitButton);
        statusLabel.setText("Enter assignment details");
    }

    @FXML
    private void handleViewStudents() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Students Enrolled:"));
        try {
            Connection conn = Database.getConnection();
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT s.name, s.gpa FROM students s JOIN users u ON s.user_id = u.id WHERE u.role = 'Student'"
            );
            while (rs.next()) {
                contentArea.getChildren().add(new Label(rs.getString("name") + " - GPA: " + rs.getDouble("gpa")));
            }
            conn.close();
            statusLabel.setText("Students loaded");
        } catch (SQLException e) {
            statusLabel.setText("Error loading students: " + e.getMessage());
        }
    }

    @FXML
    private void handleBackPrev() {
        statusLabel.setText("Back to previous page (Not fully implemented)");
    }

    @FXML
    private void handleBackLogin() {
        statusLabel.setText("Returning to Login (Not implemented yet)");
    }
}