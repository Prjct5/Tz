package com.projecttest.projecttest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DataManagementController {

    @FXML
    private Button exportButton; // زر تصدير البيانات

    @FXML
    private Button importButton; // زر استيراد البيانات

    @FXML
    private Button backButton; // زر الرجوع

    @FXML
    private TextField fullNameField; // حقل إدخال الاسم الكامل

    @FXML
    private TextField gpaField; // حقل إدخال GPA

    @FXML
    private Label statusLabel; // ليبل لعرض حالة العملية

    // دالة لفتح واجهة جديدة
    private void openNewWindow(String fxmlFile, String title) {
        try {
            // تحميل ملف الـ FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            // إنشاء نافذة جديدة
            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            // إغلاق النافذة الحالية
            Stage currentStage = (Stage) exportButton.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
            // لو حصل خطأ، بنطبع رسالة
            statusLabel.setText("Error opening window: " + fxmlFile);
        }
    }

    // دالة تصدير البيانات
    @FXML
    private void handleExportData() {
        try {
            // الاتصال بالداتابيز
            Connection conn = Database.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM students");

            // كتابة البيانات في ملف CSV
            FileWriter writer = new FileWriter("students_export.csv");
            writer.write("id,full_name,gpa\n"); // رأس الملف
            while (rs.next()) {
                int id = rs.getInt("id");
                String fullName = rs.getString("full_name");
                float gpa = rs.getFloat("gpa");
                writer.write(id + "," + fullName + "," + gpa + "\n");
            }
            writer.close();
            conn.close();

            // عرض رسالة نجاح
            statusLabel.setText("Data exported successfully to students_export.csv");
        } catch (SQLException | IOException e) {
            e.printStackTrace();
            // عرض رسالة خطأ
            statusLabel.setText("Error exporting data");
        }
    }

    // دالة استيراد البيانات
    @FXML
    private void handleImportData() {
        try {
            // جلب البيانات من الحقول
            String fullName = fullNameField.getText();
            String gpaText = gpaField.getText();

            // التحقق من إن الحقول مش فاضية
            if (fullName.isEmpty() || gpaText.isEmpty()) {
                statusLabel.setText("Please fill all fields");
                return;
            }

            // تحويل GPA لـ float
            float gpa;
            try {
                gpa = Float.parseFloat(gpaText);
                if (gpa < 0.0 || gpa > 4.0) {
                    statusLabel.setText("GPA must be between 0.0 and 4.0");
                    return;
                }
            } catch (NumberFormatException e) {
                statusLabel.setText("Invalid GPA format");
                return;
            }

            // الاتصال بالداتابيز
            Connection conn = Database.getConnection();
            String sql = "INSERT INTO students (full_name, gpa) VALUES (?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, fullName);
            pstmt.setFloat(2, gpa);
            pstmt.executeUpdate();

            // إغلاق الاتصال
            conn.close();

            // عرض رسالة نجاح
            statusLabel.setText("Student added successfully");
            fullNameField.clear();
            gpaField.clear();
        } catch (SQLException e) {
            e.printStackTrace();
            // عرض رسالة خطأ
            statusLabel.setText("Error adding student to database");
        }
    }

    // دالة الرجوع للوحة التحكم
    @FXML
    private void handleBack() {
        openNewWindow("AdminDashboard.fxml", "Admin Dashboard");
    }
}