package com.projecttest.projecttest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import java.io.IOException;

public class AdminDashboardController {

    @FXML
    private Button manageUsersButton; // زرار إدارة المستخدمين

    @FXML
    private Button systemSettingsButton; // زرار إعدادات النظام

    @FXML
    private Button dataManagementButton; // زرار إدارة البيانات

    @FXML
    private Button reportsButton; // زرار التقارير

    @FXML
    private Button logoutButton; // زرار تسجيل الخروج

    // دالة لفتح واجهة جديدة
    private void openNewWindow(String fxmlFile, String title) {
        try {
            // تحميل ملف الـ FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            // إنشاء نافذة جديدة
            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            // إغلاق النافذة الحالية
            Stage currentStage = (Stage) manageUsersButton.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
            // لو حصل خطأ، بنطبع رسالة
            System.out.println("خطأ في فتح الواجهة: " + fxmlFile);
        }
    }

    // ميثوت زرار إدارة المستخدمين
    @FXML
    private void handleManageUsers() {
        openNewWindow("ManageUsers.fxml", "Manage Users");
    }

    // ميثوت زرار إعدادات النظام
    @FXML
    private void handleSystemSettings() {
        openNewWindow("SystemSettings.fxml", "System Settings");
    }

    // ميثوت زرار إدارة البيانات
    @FXML
    private void handleDataManagement() {
        openNewWindow("DataManagement.fxml", "Data Management");
    }

    // دالة زرار التقارير
    @FXML
    private void handleReports() {
        openNewWindow("Reports.fxml", "Reports");
    }

    // دالة زرار تسجيل الخروج
    @FXML
    private void handleLogout() {
        // ارجع لصفحه تسجيل الدخول
        openNewWindow("login.fxml", "Login");
    }
}