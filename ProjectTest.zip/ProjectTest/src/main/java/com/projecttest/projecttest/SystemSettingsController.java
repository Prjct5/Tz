package com.projecttest.projecttest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.*;
import java.io.IOException;

public class SystemSettingsController {

    @FXML
    private Button languageButton;
    @FXML
    private Button permissionsButton;
    @FXML
    private Button resetButton;
    @FXML
    private Button backButton;
    @FXML
    private Label statusLabel;

    @FXML
    private void initialize() {
        statusLabel.setText("Settings loaded");
    }

    @FXML
    private void handleChangeLanguage() {
        statusLabel.setText("Change Language clicked (Not implemented yet)");
    }

    @FXML
    private void handleManagePermissions() {
        statusLabel.setText("Manage Permissions clicked (Not implemented yet)");
    }

    @FXML
    private void handleReset() {
        statusLabel.setText("Reset Settings clicked (Not implemented yet)");
    }

    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminDashboard.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Admin Dashboard");
            stage.setScene(new Scene(root));
            stage.show();
            Stage currentStage = (Stage) backButton.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
            statusLabel.setText("Error opening dashboard: " + e.getMessage());
        }
    }
}