package com.projecttest.projecttest;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentController {

    @FXML
    private VBox contentArea;
    @FXML
    private Button coursesButton;
    @FXML
    private Button videosButton;
    @FXML
    private Button tasksButton;
    @FXML
    private Button backButtonPrev;
    @FXML
    private Button backButtonLogin;
    @FXML
    private Label statusLabel;

    @FXML
    private void initialize() {
        statusLabel.setText("Welcome to Student Dashboard");
    }

    @FXML
    private void handleViewCourses() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Courses Available:"));
        try {
            Connection conn = Database.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT name, description FROM courses");
            while (rs.next()) {
                contentArea.getChildren().add(new Label(rs.getString("name") + " - " + rs.getString("description")));
            }
            conn.close();
            statusLabel.setText("Courses loaded");
        } catch (SQLException e) {
            statusLabel.setText("Error loading courses: " + e.getMessage());
        }
    }

    @FXML
    private void handleWatchVideos() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Videos Available:"));
        try {
            Connection conn = Database.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT title, url FROM videos");
            while (rs.next()) {
                contentArea.getChildren().add(new Label(rs.getString("title") + " - " + rs.getString("url")));
            }
            conn.close();
            statusLabel.setText("Videos loaded");
        } catch (SQLException e) {
            statusLabel.setText("Error loading videos: " + e.getMessage());
        }
    }

    @FXML
    private void handleCheckTasks() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Tasks Available:"));
        try {
            Connection conn = Database.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT title, deadline FROM tasks");
            while (rs.next()) {
                contentArea.getChildren().add(new Label(rs.getString("title") + " - Deadline: " + rs.getString("deadline")));
            }
            conn.close();
            statusLabel.setText("Tasks loaded");
        } catch (SQLException e) {
            statusLabel.setText("Error loading tasks: " + e.getMessage());
        }
    }

    @FXML
    private void handleBackLogin() {
        statusLabel.setText("Returning to Login (Not implemented yet)");
        // يمكن نضيف ربط لـ Login.fxml لاحقًا
    }
}