package com.projecttest.projecttest;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ManageUsersController {

    @FXML
    private TextField usernameField; // حقل إدخال اسم المستخدم

    @FXML
    private TextField emailField; // حقل إدخال الإيميل

    @FXML
    private TextField passwordField; // حقل إدخال الباسورد

    @FXML
    private ComboBox<String> roleComboBox; // قايمة اختيار الدور

    @FXML
    private Button addButton; // زرار إضافة المستخدم

    @FXML
    private Button deleteButton; // زرار حذف المستخدم

    @FXML
    private Button backButton; // زرار الرجوع

    @FXML
    private TableView<User> usersTable; // جدول المستخدمين

    @FXML
    private TableColumn<User, Integer> idColumn; // عمود ال ID

    @FXML
    private TableColumn<User, String> usernameColumn; // عمود اسم المستخدم

    @FXML
    private TableColumn<User, String> emailColumn; // عمود الإيميل

    @FXML
    private TableColumn<User, String> roleColumn; // عمود الدور

    @FXML
    private Label statusLabel; // ليبل لعرض حالة العملية

    private ObservableList<User> usersList = FXCollections.observableArrayList();

    // UserManager instance for handling user operations (Encapsulation)
    private final UserManager userManager = new UserManager();

    // كلاس داخلي لتمثيل المستخدم
    public static class User {
        private final int id;
        private final String username;
        private final String email;
        private final String role;

        public User(int id, String username, String email, String role) {
            this.id = id;
            this.username = username;
            this.email = email;
            this.role = role;
        }

        public int getId() {
            return id;
        }

        public String getUsername() {
            return username;
        }

        public String getEmail() {
            return email;
        }

        public String getRole() {
            return role;
        }
    }

    // تهيئة الجدول
    @FXML
    private void initialize() {
        // ربط الأعمدة بالبيانات
        idColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        usernameColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getUsername()));
        emailColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getEmail()));
        roleColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getRole()));

        // تحميل البيانات
        loadUsers();
    }

    // تحميل المستخدمين من الداتابيز
    private void loadUsers() {
        usersList.clear();
        try {
            Connection conn = Database.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM users");
            while (rs.next()) {
                usersList.add(new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("email"),
                        rs.getString("role")
                ));
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Error loading users: " + e.getMessage());
        }
        usersTable.setItems(usersList);
    }

    // دالة لفتح واجهة جديدة
    private void openNewWindow(String fxmlFile, String title) {
        try {
            // تحميل ملف الـ FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            // إنشاء نافذة جديدة
            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            // إغلاق النافذة الحالية
            Stage currentStage = (Stage) addButton.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
            statusLabel.setText("Error opening window: " + fxmlFile);
        }
    }

    // دالة للتحقق من وجود الإيميل
    private boolean isEmailExists(String email) throws SQLException {
        Connection conn = Database.getConnection();
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, email);
        ResultSet rs = pstmt.executeQuery();
        rs.next();
        int count = rs.getInt(1);
        conn.close();
        return count > 0;
    }

    // دالة إضافة مستخدم
    @FXML
    private void handleAddUser() {
        // جلب البيانات من الحقول
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();
        String role = roleComboBox.getValue();

        // التحقق من الحقول
        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || role == null) {
            statusLabel.setText("Please fill all fields");
            return;
        }

        // تحقق لصيغة الإيميل
        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            statusLabel.setText("Invalid email format");
            return;
        }

        // التحقق من طول الباسورد (اختياري)
        if (password.length() < 6) {
            statusLabel.setText("Password must be at least 6 characters");
            return;
        }

        try {
            // التحقق من وجود الإيميل
            if (isEmailExists(email)) {
                statusLabel.setText("Email already exists, please use a different email");
                return;
            }

            // Use UserManager to add the user
            boolean success = userManager.addUser(username, email, password, role);
            if (success) {
                // إعادة تحميل البيانات
                loadUsers();
                // عرض رسالة نجاح
                statusLabel.setText("User added successfully");
                usernameField.clear();
                emailField.clear();
                passwordField.clear();
                roleComboBox.setValue(null);
            } else {
                statusLabel.setText("Failed to add user");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Error adding user: " + e.getMessage());
        }
    }

    // دالة حذف مستخدم
    @FXML
    private void handleDeleteUser() {
        User selectedUser = usersTable.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            statusLabel.setText("Please select a user to delete");
            return;
        }

        // Use UserManager to delete the user
        boolean success = userManager.removeUser(selectedUser.getId());
        if (success) {
            // إعادة تحميل البيانات
            loadUsers();
            // عرض رسالة نجاح
            statusLabel.setText("User deleted successfully");
        } else {
            statusLabel.setText("Error deleting user");
        }
    }

    // دالة الرجوع للوحة التحكم
    @FXML
    private void handleBack() {
        openNewWindow("AdminDashboard.fxml", "Admin Dashboard");
    }
}