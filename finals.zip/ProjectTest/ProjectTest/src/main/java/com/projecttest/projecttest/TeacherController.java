package com.projecttest.projecttest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class TeacherController {

    @FXML
    private VBox contentArea;
    @FXML
    private Button coursesButton;
    @FXML
    private Button addTaskButton;
    @FXML
    private Button studentsButton;
    @FXML
    private Button backButtonPrev;
    @FXML
    private Button backButtonLogin;
    @FXML
    private Label statusLabel;

    @FXML
    private void initialize() {
        // Do not clear contentArea to preserve FXML-defined buttons
        statusLabel.setText("Welcome to Teacher Dashboard");
    }

    @FXML
    private void handleManageCourses() {
        // Clear only the dynamic content area, preserving buttons
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Courses Managed:"));
        TextField titleField = new TextField();
        titleField.setPromptText("Course Title");
        TextField descriptionField = new TextField();
        descriptionField.setPromptText("Course Description");
        TextField requirementsField = new TextField();
        requirementsField.setPromptText("Course Requirements");
        Button addCourseButton = new Button("Add Course");
        addCourseButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");

        addCourseButton.setOnAction(e -> {
            String title = titleField.getText().trim();
            String description = descriptionField.getText().trim();
            String requirements = requirementsField.getText().trim();
            if (title.isEmpty() || description.isEmpty()) {
                statusLabel.setText("Please fill title and description");
                return;
            }
            int instructorId = getCurrentUserId();
            if (instructorId == -1) {
                statusLabel.setText("User not found");
                return;
            }
            boolean success = Database.addCourse(title, description, instructorId, requirements);
            if (success) {
                statusLabel.setText("Course added successfully");
                titleField.clear();
                descriptionField.clear();
                requirementsField.clear();
            } else {
                statusLabel.setText("Failed to add course");
            }
        });

        TextField courseIdField = new TextField();
        courseIdField.setPromptText("Enter Course ID to View Videos");
        Button loadVideosButton = new Button("Load Videos");
        loadVideosButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");

        loadVideosButton.setOnAction(e -> {
            String courseIdText = courseIdField.getText().trim();
            if (courseIdText.isEmpty()) {
                statusLabel.setText("Please enter a Course ID");
                return;
            }
            try {
                int courseId = Integer.parseInt(courseIdText);
                ResultSet rs = Database.getCourseVideos(courseId);
                if (rs == null) {
                    statusLabel.setText("Error loading videos");
                    return;
                }
                contentArea.getChildren().clear();
                contentArea.getChildren().add(new Label("Videos for Course ID " + courseId + ":"));
                while (rs.next()) {
                    contentArea.getChildren().add(new Label(rs.getString("title") + " - " + rs.getString("video_url")));
                }
                rs.getStatement().getConnection().close();
                statusLabel.setText("Videos loaded");
            } catch (NumberFormatException ex) {
                statusLabel.setText("Invalid Course ID format");
            } catch (SQLException ex) {
                statusLabel.setText("Error loading videos: " + ex.getMessage());
            }
        });

        try {
            Connection conn = Database.getConnection();
            String sql = "SELECT id, title, description FROM courses WHERE instructor_id = (SELECT id FROM users WHERE username = ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, Info.currentUser);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                contentArea.getChildren().add(new Label("ID: " + rs.getInt("id") + " - " + rs.getString("title") + " - " + rs.getString("description")));
            }
            conn.close();
            contentArea.getChildren().addAll(titleField, descriptionField, requirementsField, addCourseButton, courseIdField, loadVideosButton);
            // Re-add buttons to maintain FXML structure
            contentArea.getChildren().addAll(backButtonPrev, coursesButton, addTaskButton, studentsButton, backButtonLogin, statusLabel);
            statusLabel.setText("Courses loaded");
        } catch (SQLException e) {
            statusLabel.setText("Error loading courses: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddTask() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Add New Assignment:"));
        TextField titleField = new TextField();
        titleField.setPromptText("Assignment Title");
        TextField descriptionField = new TextField();
        descriptionField.setPromptText("Description");
        TextField dueDateField = new TextField();
        dueDateField.setPromptText("Due Date (YYYY-MM-DD HH:MM:SS)");
        TextField maxGradeField = new TextField();
        maxGradeField.setPromptText("Max Grade");
        TextField courseIdField = new TextField();
        courseIdField.setPromptText("Course ID");
        Button submitButton = new Button("Submit Assignment");
        submitButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");

        submitButton.setOnAction(e -> {
            String title = titleField.getText().trim();
            String description = descriptionField.getText().trim();
            String dueDate = dueDateField.getText().trim();
            String maxGradeStr = maxGradeField.getText().trim();
            String courseIdStr = courseIdField.getText().trim();

            if (title.isEmpty() || description.isEmpty() || dueDate.isEmpty() || maxGradeStr.isEmpty() || courseIdStr.isEmpty()) {
                statusLabel.setText("Please fill all fields");
                return;
            }

            int maxGrade, courseId;
            try {
                maxGrade = Integer.parseInt(maxGradeStr);
                courseId = Integer.parseInt(courseIdStr);
                if (maxGrade <= 0) {
                    statusLabel.setText("Max Grade must be positive");
                    return;
                }
            } catch (NumberFormatException ex) {
                statusLabel.setText("Max Grade and Course ID must be valid numbers");
                return;
            }

            try {
                Timestamp dueDateTimestamp = Timestamp.valueOf(dueDate);
                boolean success = Database.addAssignment(courseId, title, description, dueDateTimestamp, maxGrade);
                if (success) {
                    statusLabel.setText("Assignment added successfully");
                    contentArea.getChildren().clear();
                    contentArea.getChildren().add(new Label("Assignment Added: " + title));
                } else {
                    statusLabel.setText("Failed to add assignment");
                }
            } catch (IllegalArgumentException ex) {
                statusLabel.setText("Invalid Due Date format");
            }
        });

        contentArea.getChildren().addAll(titleField, descriptionField, dueDateField, maxGradeField, courseIdField, submitButton);
        // Re-add buttons to maintain FXML structure
        contentArea.getChildren().addAll(backButtonPrev, coursesButton, addTaskButton, studentsButton, backButtonLogin, statusLabel);
        statusLabel.setText("Enter assignment details");
    }

    @FXML
    private void handleAddVideo() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Add New Video:"));
        TextField courseIdField = new TextField();
        courseIdField.setPromptText("Course ID");
        TextField titleField = new TextField();
        titleField.setPromptText("Video Title");
        TextField descriptionField = new TextField();
        descriptionField.setPromptText("Description");
        TextField videoUrlField = new TextField();
        videoUrlField.setPromptText("Video URL");
        TextField durationField = new TextField();
        durationField.setPromptText("Duration (seconds)");
        TextField orderNumberField = new TextField();
        orderNumberField.setPromptText("Order Number");
        Button submitButton = new Button("Add Video");
        submitButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");

        submitButton.setOnAction(e -> {
            String courseIdText = courseIdField.getText().trim();
            String title = titleField.getText().trim();
            String description = descriptionField.getText().trim();
            String videoUrl = videoUrlField.getText().trim();
            String durationText = durationField.getText().trim();
            String orderNumberText = orderNumberField.getText().trim();

            if (courseIdText.isEmpty() || title.isEmpty() || videoUrl.isEmpty() || durationText.isEmpty() || orderNumberText.isEmpty()) {
                statusLabel.setText("Please fill all fields");
                return;
            }

            int courseId, duration, orderNumber;
            try {
                courseId = Integer.parseInt(courseIdText);
                duration = Integer.parseInt(durationText);
                orderNumber = Integer.parseInt(orderNumberText);
                if (duration <= 0 || orderNumber < 0) {
                    statusLabel.setText("Duration must be positive and Order Number non-negative");
                    return;
                }
            } catch (NumberFormatException ex) {
                statusLabel.setText("Course ID, Duration, and Order Number must be valid numbers");
                return;
            }

            boolean success = Database.addCourseVideo(courseId, title, description, videoUrl, null, duration, orderNumber);
            if (success) {
                statusLabel.setText("Video added successfully");
                contentArea.getChildren().clear();
                contentArea.getChildren().add(new Label("Video Added: " + title));
            } else {
                statusLabel.setText("Failed to add video");
            }
        });

        contentArea.getChildren().addAll(courseIdField, titleField, descriptionField, videoUrlField, durationField, orderNumberField, submitButton);
        // Re-add buttons to maintain FXML structure
        contentArea.getChildren().addAll(backButtonPrev, coursesButton, addTaskButton, studentsButton, backButtonLogin, statusLabel);
        statusLabel.setText("Enter video details");
    }

    @FXML
    private void handleViewStudents() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Students Enrolled:"));
        try {
            Connection conn = Database.getConnection();
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT s.full_name, s.gpa FROM students s JOIN users u ON s.user_id = u.id WHERE u.role = 'Student'"
            );
            while (rs.next()) {
                contentArea.getChildren().add(new Label(rs.getString("full_name") + " - GPA: " + rs.getDouble("gpa")));
            }
            conn.close();
            // Re-add buttons to maintain FXML structure
            contentArea.getChildren().addAll(backButtonPrev, coursesButton, addTaskButton, studentsButton, backButtonLogin, statusLabel);
            statusLabel.setText("Students loaded");
        } catch (SQLException e) {
            statusLabel.setText("Error loading students: " + e.getMessage());
        }
    }

    @FXML
    private void handleBackPrev() {
        contentArea.getChildren().clear();
        // Re-add buttons to maintain FXML structure
        contentArea.getChildren().addAll(backButtonPrev, coursesButton, addTaskButton, studentsButton, backButtonLogin, statusLabel);
        statusLabel.setText("Returned to Teacher Dashboard");
    }

    @FXML
    private void handleBackLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
            Stage stage = (Stage) backButtonLogin.getScene().getWindow();
            stage.setScene(new Scene(loader.load()));
            stage.setTitle("Login");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            statusLabel.setText("Error returning to login");
        }
    }

    private int getCurrentUserId() {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT id FROM users WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, Info.currentUser);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}