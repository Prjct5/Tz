package com.projecttest.projecttest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.util.Map;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label statusLabel;

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        Map<String, String> userData = Database.loginUser(username, password);

        if (userData != null) {
            String role = userData.get("role");
            Info.currentUser = username; // Set current user
            Info.currentRole = role;    // Set current role
            statusLabel.setText("Login successful! Role: " + role);
            try {
                FXMLLoader loader;
                if (role.equals("Teacher")) {
                    loader = new FXMLLoader(getClass().getResource("Mesarw3Teacher.fxml"));
                } else if (role.equals("Admin")) {
                    loader = new FXMLLoader(getClass().getResource("AdminDashboard.fxml"));
                } else {
                    loader = new FXMLLoader(getClass().getResource("haythamSTUDENT.fxml"));
                }
                Stage stage = (Stage) usernameField.getScene().getWindow();
                stage.setScene(new Scene(loader.load()));
                stage.setTitle(role + " Dashboard");
            } catch (Exception e) {
                e.printStackTrace();
                statusLabel.setText("Error loading dashboard: " + e.getMessage());
            }
        } else {
            statusLabel.setText("Invalid username or password.");
        }
    }

    @FXML
    private void handleGoToRegister() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("register.fxml"));
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(new Scene(loader.load()));
        } catch (Exception e) {
            e.printStackTrace();
            statusLabel.setText("Error loading register page: " + e.getMessage());
        }
    }
}