package com.projecttest.projecttest;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class Database {
    private static final String URL = "jdbc:postgresql://localhost:5432/oop2";
    private static final String USER = "postgres";
    private static final String PASSWORD = "ym";

    // Register user
    public static boolean registerUser(String username, String email, String password, String role) {
        String checkSql = "SELECT username FROM users WHERE username = ?";
        String insertSql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            // Check if username exists
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, username);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                return false; // Username already exists
            }

            // Insert new user
            PreparedStatement insertStmt = conn.prepareStatement(insertSql);
            insertStmt.setString(1, username);
            insertStmt.setString(2, email);
            insertStmt.setString(3, password); // Store password as plain text
            insertStmt.setString(4, role);
            insertStmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Login user
    public static Map<String, String> loginUser(String username, String password) {
        String sql = "SELECT id, email, password, role FROM users WHERE username = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("password");
                if (password.equals(storedPassword)) { // Compare plain text password
                    Map<String, String> userData = new HashMap<>();
                    userData.put("id", rs.getString("id"));
                    userData.put("email", rs.getString("email"));
                    userData.put("role", rs.getString("role"));
                    return userData;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Add student data
    public static boolean addStudent(int userId, String studentId, String organisation, String level, double gpa) {
        String sql = "INSERT INTO students (user_id, student_id, organisation, level, gpa) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setString(2, studentId);
            stmt.setString(3, organisation);
            stmt.setString(4, level);
            stmt.setDouble(5, gpa);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Add course
    public static boolean addCourse(String title, String description, int instructorId, String requirements) {
        String sql = "INSERT INTO courses (title, description, instructor_id, requirements) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.setInt(3, instructorId);
            stmt.setString(4, requirements);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Add course video
    public static boolean addCourseVideo(int courseId, String title, String description, String videoUrl, String videoFilePath, int duration, int orderNumber) {
        String sql = "INSERT INTO course_videos (course_id, title, description, video_url, video_file_path, duration, order_number) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, courseId);
            stmt.setString(2, title);
            stmt.setString(3, description);
            stmt.setString(4, videoUrl);
            stmt.setString(5, videoFilePath);
            stmt.setInt(6, duration);
            stmt.setInt(7, orderNumber);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Enroll student in course
    public static boolean enrollStudentInCourse(int studentId, int courseId) {
        String sql = "INSERT INTO course_enrollments (student_id, course_id) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Add assignment
    public static boolean addAssignment(int courseId, String title, String description, Timestamp dueDate, int maxGrade) {
        String sql = "INSERT INTO assignments (course_id, title, description, due_date, max_grade) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, courseId);
            stmt.setString(2, title);
            stmt.setString(3, description);
            stmt.setTimestamp(4, dueDate);
            stmt.setInt(5, maxGrade);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Submit assignment
    public static boolean submitAssignment(int assignmentId, int studentId, String submissionFile, String submissionText) {
        String sql = "INSERT INTO assignment_submissions (assignment_id, student_id, submission_file, submission_text) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, assignmentId);
            stmt.setInt(2, studentId);
            stmt.setString(3, submissionFile);
            stmt.setString(4, submissionText);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Save system setting
    public static boolean saveSetting(String name, String value) {
        String sql = "INSERT INTO settings (setting_name, setting_value) VALUES (?, ?) ON CONFLICT (setting_name) DO UPDATE SET setting_value = ?, updated_at = CURRENT_TIMESTAMP";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, value);
            stmt.setString(3, value);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get course videos
    public static ResultSet getCourseVideos(int courseId) {
        String sql = "SELECT id, title, description, video_url, video_file_path, duration, order_number FROM course_videos WHERE course_id = ? ORDER BY order_number";

        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, courseId);
            return stmt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Get assignments for a course
    public static ResultSet getAssignments(int courseId) {
        String sql = "SELECT id, title, description, due_date, max_grade FROM assignments WHERE course_id = ?";

        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, courseId);
            return stmt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Connection getConnection() throws SQLException {
        try {
            // تحميل درايفر PostgreSQL
            Class.forName("org.postgresql.Driver");
            // إنشاء الاتصال
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new SQLException("PostgreSQL JDBC Driver not found");
        }
    }
}
/*
    // Test connection
    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Connected to database successfully!");

            // Test registering a user
            boolean registered = registerUser("testuser", "test@example.com", "password123", "Student");
            System.out.println("User registered: " + registered);

            // Test login
            Map<String, String> userData = loginUser("testuser", "password123");
            System.out.println("Login result: " + userData);

            // Test adding a course
            boolean courseAdded = addCourse("Math 101", "Basic Math Course", 1, "None");
            System.out.println("Course added: " + courseAdded);

            // Test adding a video
            boolean videoAdded = addCourseVideo(1, "Lecture 1", "Introduction", "https://youtube.com/watch?v=abc123", null, 600, 1);
            System.out.println("Video added: " + videoAdded);

            // Test adding an assignment
            boolean assignmentAdded = addAssignment(1, "Assignment 1", "Solve exercises", Timestamp.valueOf("2025-06-01 23:59:59"), 100);
            System.out.println("Assignment added: " + assignmentAdded);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}*/