package com.projecttest.projecttest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.*;
import java.io.IOException;

public class SystemSettingsController {

    @FXML
    private Button languageButton;
    @FXML
    private Button permissionsButton;
    @FXML
    private Button resetButton;
    @FXML
    private Button backButton;
    @FXML
    private TextField languageField; // New field for language
    @FXML
    private TextField permissionField; // New field for permissions
    @FXML
    private Label statusLabel;

    @FXML
    private void initialize() {
        statusLabel.setText("Settings loaded");
    }

    @FXML
    private void handleChangeLanguage() {
        String language = languageField.getText().trim();
        if (language.isEmpty()) {
            statusLabel.setText("Please enter a language");
            return;
        }
        boolean success = Database.saveSetting("language", language);
        if (success) {
            statusLabel.setText("Language set to " + language);
            languageField.clear();
        } else {
            statusLabel.setText("Failed to set language");
        }
    }

    @FXML
    private void handleManagePermissions() {
        String permission = permissionField.getText().trim();
        if (permission.isEmpty()) {
            statusLabel.setText("Please enter a permission setting");
            return;
        }
        boolean success = Database.saveSetting("permission", permission);
        if (success) {
            statusLabel.setText("Permission set to " + permission);
            permissionField.clear();
        } else {
            statusLabel.setText("Failed to set permission");
        }
    }

    @FXML
    private void handleReset() {
        boolean success = Database.saveSetting("language", "default") && Database.saveSetting("permission", "default");
        if (success) {
            statusLabel.setText("Settings reset to default");
            languageField.clear();
            permissionField.clear();
        } else {
            statusLabel.setText("Failed to reset settings");
        }
    }

    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminDashboard.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Admin Dashboard");
            stage.setScene(new Scene(root));
            stage.show();
            Stage currentStage = (Stage) backButton.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
            statusLabel.setText("Error opening dashboard: " + e.getMessage());
        }
    }
}