package com.projecttest.projecttest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DataManagementController {

    @FXML
    private Button exportButton;
    @FXML
    private Button importButton;
    @FXML
    private Button backButton;
    @FXML
    private TextField fullNameField;
    @FXML
    private TextField gpaField;
    @FXML
    private TextField studentIdField; // New field for student ID
    @FXML
    private TextField organisationField; // New field for organisation
    @FXML
    private TextField levelField; // New field for level
    @FXML
    private TextField courseIdField; // New field for course ID
    @FXML
    private Label statusLabel;

    private void openNewWindow(String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
            Stage currentStage = (Stage) exportButton.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
            statusLabel.setText("Error opening window: " + fxmlFile);
        }
    }

    @FXML
    private void handleExportData() {
        try {
            Connection conn = Database.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM students");
            FileWriter writer = new FileWriter("students_export.csv");
            writer.write("id,full_name,gpa,student_id,organisation,level\n");
            while (rs.next()) {
                int id = rs.getInt("id");
                String fullName = rs.getString("full_name");
                float gpa = rs.getFloat("gpa");
                String studentId = rs.getString("student_id");
                String organisation = rs.getString("organisation");
                String level = rs.getString("level");
                writer.write(id + "," + fullName + "," + gpa + "," + studentId + "," + organisation + "," + level + "\n");
            }
            writer.close();
            conn.close();
            statusLabel.setText("Data exported successfully to students_export.csv");
        } catch (SQLException | IOException e) {
            e.printStackTrace();
            statusLabel.setText("Error exporting data");
        }
    }

    @FXML
    private void handleImportData() {
        try {
            String fullName = fullNameField.getText().trim();
            String gpaText = gpaField.getText().trim();
            String studentId = studentIdField.getText().trim();
            String organisation = organisationField.getText().trim();
            String level = levelField.getText().trim();
            String courseIdText = courseIdField.getText().trim();

            // Validate inputs
            if (fullName.isEmpty() || gpaText.isEmpty() || studentId.isEmpty() || organisation.isEmpty() || level.isEmpty()) {
                statusLabel.setText("Please fill all required fields");
                return;
            }

            float gpa;
            try {
                gpa = Float.parseFloat(gpaText);
                if (gpa < 0.0 || gpa > 4.0) {
                    statusLabel.setText("GPA must be between 0.0 and 4.0");
                    return;
                }
            } catch (NumberFormatException e) {
                statusLabel.setText("Invalid GPA format");
                return;
            }

            // Get current user ID from Info
            int userId;
            try (Connection conn = Database.getConnection()) {
                String sql = "SELECT id FROM users WHERE username = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, Info.currentUser);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    userId = rs.getInt("id");
                } else {
                    statusLabel.setText("User not found");
                    return;
                }
            }

            // Add student using Database method
            boolean success = Database.addStudent(userId, studentId, organisation, level, gpa);
            if (success) {
                // Enroll in course if courseId is provided
                if (!courseIdText.isEmpty()) {
                    try {
                        int courseId = Integer.parseInt(courseIdText);
                        boolean enrolled = Database.enrollStudentInCourse(userId, courseId);
                        if (enrolled) {
                            statusLabel.setText("Student added and enrolled in course successfully");
                        } else {
                            statusLabel.setText("Student added but failed to enroll in course");
                        }
                    } catch (NumberFormatException e) {
                        statusLabel.setText("Invalid Course ID format");
                        return;
                    }
                } else {
                    statusLabel.setText("Student added successfully");
                }
                fullNameField.clear();
                gpaField.clear();
                studentIdField.clear();
                organisationField.clear();
                levelField.clear();
                courseIdField.clear();
            } else {
                statusLabel.setText("Error adding student to database");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Database error: " + e.getMessage());
        }
    }

    @FXML
    private void handleBack() {
        openNewWindow("AdminDashboard.fxml", "Admin Dashboard");
    }
}