package com.projecttest.projecttest;

public class Info {
    public static String currentUser = "";
    public static String currentRole = "";
}